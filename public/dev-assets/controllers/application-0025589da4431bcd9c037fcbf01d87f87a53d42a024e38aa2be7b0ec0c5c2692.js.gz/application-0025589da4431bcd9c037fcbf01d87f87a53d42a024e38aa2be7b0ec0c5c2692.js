import { Application } from "@hotwired/stimulus"

const application = Application.start()

// Configure Stimulus development experience
application.debug = false
window.Stimulus = application
console.log("🧠 Stimulus started and assigned to window")
export { application }
;
